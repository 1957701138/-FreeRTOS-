
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'MAX30100_MPU6050' 
 * Target:  'MAX30100_MPU6050' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "cs32f10x.h"



#endif /* RTE_COMPONENTS_H */
